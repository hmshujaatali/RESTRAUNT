// console.log(firebase.database())
let signIn = () => {
    var email = document.getElementById("emaill").value
    console.log(email)
    var password = document.getElementById("passs").value
    console.log(password)
    firebase.auth().signInWithEmailAndPassword(email, password)
        .then((userCredential) => {
            var user = userCredential.user;
            console.log(user.uid);
            console.log(user.email);
            console.log(user);
            alert("login done")
        })
        .catch((error) => {
            var errorMessage = error.message;
            console.log(errorMessage);
            alert("Register Yourself")
            // window.location = "signUp.html";
        });
}



var obj = {
    name: "name",
    email: "email",
    password: "password",
}