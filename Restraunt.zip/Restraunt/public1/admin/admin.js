console.log(firebase.database())
let signUp = () => {
    var email = document.getElementById("email").value
    var password = document.getElementById("pass").value
    console.log(email,password);
    firebase.auth().createUserWithEmailAndPassword(email, password)
        .then((userCredential) => {
            // Signed in 
            var user = userCredential.user;
            console.log(user);
            alert("register Sucess")
            window.location = "signIn.html";
            // ...
        })
        .catch((error) => {
            var errorMessage = error.message;
            console.log(errorMessage);
            alert("there is some error")
            // ..
        });
}
// console.log(firebase.database())
// let signIn = () => {
//     var email = document.getElementById("emaill").value
//     var password = document.getElementById("passs").value
//     console.log(email,password)
//     firebase.auth().signInWithEmailAndPassword(email, password)
//         .then((userCredential) => {
//             var user = userCredential.user;
//             console.log(user.uid);
//             console.log(user.email);
//             console.log(user);
//             alert("login done")
//         })
//         .catch((error) => {
//             var errorMessage = error.message;
//             console.log(errorMessage);
//             alert("Register Yourself")
//             window.location = "signUp.html";
//         });
// }



// var obj = {
//     name: "name",
//     email: "email",
//     password: "password",
// }